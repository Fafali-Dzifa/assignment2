# face_detection_using_haar_cascade
This is python code to detect faces on image using haar-like features OpenCV
